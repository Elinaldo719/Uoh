'use client'

import { useState, useRef, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import { useActionState } from 'react'
import AudioPlayer from '../components/AudioPlayer'
import AudioList from '../components/AudioList'
import Controls from '../components/Controls'
import UploadButton from '../components/UploadButton'
import DynamicBackground from '../components/DynamicBackground'
import PlaylistIcon from '../components/PlaylistIcon'
import { Audio } from '../types/audio'
import Link from 'next/link'
import { Heart } from 'lucide-react'

interface Playlist {
  id: string;
  name: string;
  songs: Audio[];
}

export default function Home() {
  const [audioFiles, setAudioFiles] = useState<Audio[]>([])
  const [currentAudio, setCurrentAudio] = useState<Audio | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isRandom, setIsRandom] = useState(false)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const [currentPlaylist, setCurrentPlaylist] = useState<Playlist | null>(null)
  const [isShufflePlaylist, setIsShufflePlaylist] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)
  const searchParams = useSearchParams()
  const [state, action, isPending] = useActionState()

  useEffect(() => {
    const savedAudios = localStorage.getItem('audioFiles')
    if (savedAudios) {
      const parsedAudios = JSON.parse(savedAudios)
      setAudioFiles(parsedAudios)
    }

    const savedPlaylist = localStorage.getItem('currentPlaylist')
    if (savedPlaylist) {
      setCurrentPlaylist(JSON.parse(savedPlaylist))
      const isShufflePlaylist = localStorage.getItem('isShufflePlaylist')
      setIsShufflePlaylist(isShufflePlaylist === 'true')
      localStorage.removeItem('currentPlaylist')
      localStorage.removeItem('isShufflePlaylist')
    }
  }, [])

  useEffect(() => {
    const playAudioId = searchParams.get('play')
    if (playAudioId) {
      const audioToPlay = audioFiles.find((audio) => audio.id === playAudioId)
      if (audioToPlay) {
        playAudio(audioToPlay)
      }
    }
  }, [searchParams, audioFiles])

  useEffect(() => {
    localStorage.setItem('audioFiles', JSON.stringify(audioFiles))
  }, [audioFiles])

  useEffect(() => {
    if (currentPlaylist && currentPlaylist.songs.length > 0) {
      setAudioFiles(currentPlaylist.songs)
      const firstSong = isShufflePlaylist
        ? currentPlaylist.songs[Math.floor(Math.random() * currentPlaylist.songs.length)]
        : currentPlaylist.songs[0]
      playAudio(firstSong)
    }
  }, [currentPlaylist, isShufflePlaylist])

  useEffect(() => {
    if (state && state.type === 'success') {
      // Handle successful action
      console.log('Action successful:', state.data)
    }
  }, [state])

  const handleUpload = (files: FileList) => {
    const newAudios = Array.from(files).map((file) => ({
      id: Date.now().toString(),
      name: file.name,
      url: URL.createObjectURL(file),
      isFavorite: false,
    }))
    setAudioFiles((prev) => [...prev, ...newAudios])
    
    if (newAudios.length > 0) {
      playAudio(newAudios[0])
    }
  }

  const toggleFavorite = (id: string) => {
    setAudioFiles((prev) =>
      prev.map((audio) =>
        audio.id === id ? { ...audio, isFavorite: !audio.isFavorite } : audio
      )
    )
  }

  const playAudio = (audio: Audio) => {
    setCurrentAudio({...audio, lastPlayed: new Date()})
    setIsPlaying(true)
    setAudioFiles((prev) =>
      prev.map((a) =>
        a.id === audio.id ? {...a, lastPlayed: new Date()} : a
      )
    )
  }

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const playNext = () => {
    if (audioFiles.length === 0) return;

    let nextIndex: number;
    if (isRandom || isShufflePlaylist) {
      nextIndex = Math.floor(Math.random() * audioFiles.length);
    } else {
      const currentIndex = audioFiles.findIndex((a) => a.id === currentAudio?.id);
      nextIndex = (currentIndex + 1) % audioFiles.length;
    }
    playAudio(audioFiles[nextIndex]);
  }

  const playPrevious = () => {
    if (audioFiles.length === 0) return;

    let previousIndex: number;
    if (isRandom || isShufflePlaylist) {
      previousIndex = Math.floor(Math.random() * audioFiles.length);
    } else {
      const currentIndex = audioFiles.findIndex((a) => a.id === currentAudio?.id);
      previousIndex = (currentIndex - 1 + audioFiles.length) % audioFiles.length;
    }
    playAudio(audioFiles[previousIndex]);
  }

  const handleTimeUpdate = (currentTime: number, audioDuration: number) => {
    setProgress((currentTime / audioDuration) * 100)
    setDuration(audioDuration)
  }

  const handleAudioEnd = () => {
    playNext();
  }

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, '0')}`
  }

  const toggleRandom = () => {
    setIsRandom(!isRandom);
  }

  const handleVolumeChange = (newVolume: number) => {
    setVolume(newVolume)
    if (audioRef.current) {
      audioRef.current.volume = newVolume
    }
  }

  return (
    <>
      <DynamicBackground currentAudio={currentAudio?.id || null} />
      <div className="min-h-screen bg-gradient-to-br from-gray-900/80 to-gray-800/80 text-white p-4 sm:p-8">
        <div className="max-w-md mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold mb-8 text-center">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
              Uoh
            </span>
          </h1>
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="flex items-center space-x-4">
              <UploadButton onUpload={handleUpload} />
              <Link href="/favorites" className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-600 hover:bg-purple-700 transition duration-300">
                <Heart className="w-6 h-6 text-white" />
              </Link>
              <PlaylistIcon />
            </div>
          </div>
          {currentPlaylist && (
            <div className="mb-4 text-center">
              <p className="text-lg font-semibold">
                Tocando playlist: {currentPlaylist.name}
              </p>
              <p className="text-sm text-gray-400">
                {isShufflePlaylist ? 'Modo aleatório' : 'Modo sequencial'}
              </p>
            </div>
          )}
          <AudioPlayer
            audio={currentAudio}
            isPlaying={isPlaying}
            onTimeUpdate={handleTimeUpdate}
            onEnded={handleAudioEnd}
            audioRef={audioRef}
          />
          <div className="mb-4">
            <div className="bg-gray-700 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full transition-all duration-300 ease-in-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex justify-between text-sm mt-1">
              <span>{formatTime(duration * (progress / 100))}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
          <Controls
            isPlaying={isPlaying}
            onTogglePlay={togglePlay}
            onNext={playNext}
            onPrevious={playPrevious}
            isRandom={isRandom || isShufflePlaylist}
            onToggleRandom={toggleRandom}
            volume={volume}
            onVolumeChange={handleVolumeChange}
          />
          <AudioList
            audioFiles={audioFiles}
            onPlay={playAudio}
            onToggleFavorite={toggleFavorite}
            currentAudio={currentAudio}
          />
        </div>
      </div>
    </>
  )
}

