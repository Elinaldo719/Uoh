'use client'

import { useState, useEffect } from 'react'
import { Audio } from '../../types/audio'
import AudioList from '../../components/AudioList'
import DynamicBackground from '../../components/DynamicBackground'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export default function Favorites() {
  const [favorites, setFavorites] = useState<Audio[]>([])

  useEffect(() => {
    const savedAudios = localStorage.getItem('audioFiles')
    if (savedAudios) {
      const allAudios = JSON.parse(savedAudios)
      setFavorites(allAudios.filter((audio: Audio) => audio.isFavorite))
    }
  }, [])

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.map((audio) =>
        audio.id === id ? { ...audio, isFavorite: !audio.isFavorite } : audio
      )
    )
    
    const savedAudios = localStorage.getItem('audioFiles')
    if (savedAudios) {
      const allAudios = JSON.parse(savedAudios)
      const updatedAudios = allAudios.map((audio: Audio) =>
        audio.id === id ? { ...audio, isFavorite: !audio.isFavorite } : audio
      )
      localStorage.setItem('audioFiles', JSON.stringify(updatedAudios))
    }
  }

  return (
    <>
      <DynamicBackground currentAudio={null} />
      <div className="min-h-screen bg-gradient-to-br from-gray-900/80 to-gray-800/80 text-white p-4 sm:p-8">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Link href="/" className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700 transition duration-300">
              <ArrowLeft className="w-6 h-6 text-white" />
            </Link>
            <h1 className="text-3xl sm:text-4xl font-bold text-center">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
                Favoritos
              </span>
            </h1>
          </div>
          <AudioList
            audioFiles={favorites}
            onPlay={() => {}}
            onToggleFavorite={toggleFavorite}
            currentAudio={null}
          />
        </div>
      </div>
    </>
  )
}

