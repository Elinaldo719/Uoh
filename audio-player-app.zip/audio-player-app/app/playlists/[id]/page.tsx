'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Play, Trash2, Shuffle } from 'lucide-react'
import { Audio } from '../../../types/audio'

interface Playlist {
  id: string;
  name: string;
  songs: Audio[];
}

export default function PlaylistPage() {
  const params = useParams()
  const router = useRouter()
  const [playlist, setPlaylist] = useState<Playlist | null>(null)
  const [allAudios, setAllAudios] = useState<Audio[]>([])

  useEffect(() => {
    const savedPlaylists = localStorage.getItem('playlists')
    const savedAudios = localStorage.getItem('audioFiles')
    if (savedPlaylists && savedAudios) {
      const playlists: Playlist[] = JSON.parse(savedPlaylists)
      const currentPlaylist = playlists.find(p => p.id === params.id)
      if (currentPlaylist) {
        setPlaylist(currentPlaylist)
      } else {
        router.push('/playlists')
      }
      setAllAudios(JSON.parse(savedAudios))
    }
  }, [params.id, router])

  const addToPlaylist = (audio: Audio) => {
    if (playlist) {
      const updatedPlaylist = {
        ...playlist,
        songs: [...playlist.songs, audio]
      }
      setPlaylist(updatedPlaylist)
      updatePlaylistInStorage(updatedPlaylist)
    }
  }

  const removeFromPlaylist = (audioId: string) => {
    if (playlist) {
      const updatedPlaylist = {
        ...playlist,
        songs: playlist.songs.filter(song => song.id !== audioId)
      }
      setPlaylist(updatedPlaylist)
      updatePlaylistInStorage(updatedPlaylist)
    }
  }

  const updatePlaylistInStorage = (updatedPlaylist: Playlist) => {
    const savedPlaylists = localStorage.getItem('playlists')
    if (savedPlaylists) {
      const playlists: Playlist[] = JSON.parse(savedPlaylists)
      const updatedPlaylists = playlists.map(p => 
        p.id === updatedPlaylist.id ? updatedPlaylist : p
      )
      localStorage.setItem('playlists', JSON.stringify(updatedPlaylists))
    }
  }

  const playPlaylist = (shuffle: boolean) => {
    if (playlist) {
      localStorage.setItem('currentPlaylist', JSON.stringify(playlist))
      localStorage.setItem('isShufflePlaylist', JSON.stringify(shuffle))
      router.push('/')
    }
  }

  if (!playlist) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900/80 to-gray-800/80 text-white p-4 sm:p-8">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/playlists" className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700 transition duration-300">
            <ArrowLeft className="w-6 h-6 text-white" />
          </Link>
          <h1 className="text-3xl sm:text-4xl font-bold text-center">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-600">
              {playlist.name}
            </span>
          </h1>
        </div>

        <div className="flex justify-center space-x-4 mb-6">
          <button
            onClick={() => playPlaylist(false)}
            className="px-4 py-2 bg-green-600 rounded-full hover:bg-green-700 transition duration-300 flex items-center"
          >
            <Play className="w-5 h-5 mr-2" /> Tocar
          </button>
          <button
            onClick={() => playPlaylist(true)}
            className="px-4 py-2 bg-purple-600 rounded-full hover:bg-purple-700 transition duration-300 flex items-center"
          >
            <Shuffle className="w-5 h-5 mr-2" /> Aleatório
          </button>
        </div>

        <h2 className="text-2xl font-semibold mb-4">Músicas na Playlist</h2>
        <ul className="space-y-2 mb-8">
          {playlist.songs.map(song => (
            <li key={song.id} className="flex items-center justify-between bg-gray-800 rounded-lg p-2">
              <span className="truncate">{song.name}</span>
              <div className="flex items-center space-x-2">
                <Link href={`/?play=${song.id}`}>
                  <Play className="w-5 h-5 text-green-500 hover:text-green-400 transition duration-300" />
                </Link>
                <button onClick={() => removeFromPlaylist(song.id)}>
                  <Trash2 className="w-5 h-5 text-red-500 hover:text-red-400 transition duration-300" />
                </button>
              </div>
            </li>
          ))}
        </ul>

        <h2 className="text-2xl font-semibold mb-4">Adicionar Músicas</h2>
        <ul className="space-y-2">
          {allAudios.filter(audio => !playlist.songs.some(song => song.id === audio.id)).map(audio => (
            <li key={audio.id} className="flex items-center justify-between bg-gray-800 rounded-lg p-2">
              <span className="truncate">{audio.name}</span>
              <button onClick={() => addToPlaylist(audio)} className="text-green-500 hover:text-green-400 transition duration-300">
                Adicionar
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

