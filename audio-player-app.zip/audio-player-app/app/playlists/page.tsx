'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, Plus, Trash2, Play } from 'lucide-react'
import { Audio } from '../../types/audio'

interface Playlist {
  id: string;
  name: string;
  songs: Audio[];
}

export default function PlaylistsPage() {
  const [playlists, setPlaylists] = useState<Playlist[]>([])
  const [newPlaylistName, setNewPlaylistName] = useState('')

  useEffect(() => {
    const savedPlaylists = localStorage.getItem('playlists')
    if (savedPlaylists) {
      setPlaylists(JSON.parse(savedPlaylists))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('playlists', JSON.stringify(playlists))
  }, [playlists])

  const createPlaylist = () => {
    if (newPlaylistName.trim()) {
      const newPlaylist: Playlist = {
        id: Date.now().toString(),
        name: newPlaylistName.trim(),
        songs: []
      }
      setPlaylists([...playlists, newPlaylist])
      setNewPlaylistName('')
    }
  }

  const deletePlaylist = (id: string) => {
    setPlaylists(playlists.filter(playlist => playlist.id !== id))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900/80 to-gray-800/80 text-white p-4 sm:p-8">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link href="/" className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700 transition duration-300">
            <ArrowLeft className="w-6 h-6 text-white" />
          </Link>
          <h1 className="text-3xl sm:text-4xl font-bold text-center">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-600">
              Playlists
            </span>
          </h1>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              placeholder="Nome da nova playlist"
              className="flex-grow p-2 rounded-lg bg-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={createPlaylist}
              className="p-2 bg-green-600 rounded-lg hover:bg-green-700 transition duration-300"
            >
              <Plus className="w-6 h-6" />
            </button>
          </div>
        </div>

        <ul className="space-y-4">
          {playlists.map(playlist => (
            <li key={playlist.id} className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold">{playlist.name}</h3>
                <div className="flex items-center space-x-2">
                  <Link href={`/playlists/${playlist.id}`}>
                    <Play className="w-6 h-6 text-green-500 hover:text-green-400 transition duration-300" />
                  </Link>
                  <button onClick={() => deletePlaylist(playlist.id)}>
                    <Trash2 className="w-6 h-6 text-red-500 hover:text-red-400 transition duration-300" />
                  </button>
                </div>
              </div>
              <p className="text-sm text-gray-400 mt-1">{playlist.songs.length} músicas</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

