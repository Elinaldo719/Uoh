import React, { useState, useEffect } from 'react';

interface DynamicBackgroundProps {
  currentAudio: string | null;
}

const DynamicBackground: React.FC<DynamicBackgroundProps> = ({ currentAudio }) => {
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);

  useEffect(() => {
    if (currentAudio) {
      // Aqui você pode implementar uma lógica para escolher imagens baseadas no áudio
      // Por enquanto, vamos usar imagens aleatórias do Unsplash
      const fetchRandomImage = async () => {
        try {
          const response = await fetch('https://source.unsplash.com/random/1920x1080/?abstract');
          setBackgroundImage(response.url);
        } catch (error) {
          console.error('Erro ao buscar imagem de fundo:', error);
        }
      };

      fetchRandomImage();
    }
  }, [currentAudio]);

  if (!backgroundImage) return null;

  return (
    <div
      className="fixed inset-0 z-[-1] transition-opacity duration-1000 ease-in-out"
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        opacity: 0.2, // Ajuste este valor para controlar a transparência
      }}
    />
  );
};

export default DynamicBackground;

