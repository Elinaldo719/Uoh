import { useState, useEffect, useRef } from 'react'
import { Audio } from '../types/audio'

interface AudioPlayerProps {
  audio: Audio | null
  isPlaying: boolean
  onTimeUpdate: (currentTime: number, duration: number) => void
  onEnded: () => void
  audioRef: React.RefObject<HTMLAudioElement>
}

export default function AudioPlayer({ audio, isPlaying, onTimeUpdate, onEnded, audioRef }: AudioPlayerProps) {
  // Remova esta linha:
  // const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    const audioElement = audioRef.current
    if (audioElement) {
      const handleTimeUpdate = () => {
        onTimeUpdate(audioElement.currentTime, audioElement.duration)
      }

      audioElement.addEventListener('timeupdate', handleTimeUpdate)
      audioElement.addEventListener('ended', onEnded)
      return () => {
        audioElement.removeEventListener('timeupdate', handleTimeUpdate)
        audioElement.removeEventListener('ended', onEnded)
      }
    }
  }, [onTimeUpdate, onEnded])

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(error => console.error("Erro ao reproduzir áudio:", error))
      } else {
        audioRef.current.pause()
      }
    }
  }, [isPlaying, audio])

  useEffect(() => {
    if (audio && audioRef.current) {
      audioRef.current.play().catch(error => console.error("Erro ao reproduzir áudio:", error))
    }
  }, [audio])


  if (!audio) return null

  return (
    <div className="mb-4 sm:mb-6">
      <h2 className="text-lg sm:text-xl font-semibold mb-2 truncate">{audio.name}</h2>
      <audio 
        ref={audioRef} 
        src={audio.url} 
        className="hidden"
        onPlay={() => console.log("Áudio iniciado")}
        onError={(e) => console.error("Erro ao reproduzir áudio:", e)}
      />
    </div>
  )
}

