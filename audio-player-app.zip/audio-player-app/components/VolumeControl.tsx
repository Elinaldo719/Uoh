import { useState } from 'react'
import { Volume2 } from 'lucide-react'

interface VolumeControlProps {
  volume: number
  onVolumeChange: (value: number) => void
}

export default function VolumeControl({ volume, onVolumeChange }: VolumeControlProps) {
  const [isVisible, setIsVisible] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setIsVisible(!isVisible)}
        className="p-2 rounded-full hover:bg-gray-700 focus:outline-none"
      >
        <Volume2 className="w-5 h-5" />
      </button>
      {isVisible && (
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-gray-800 rounded-lg p-2">
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
            className="w-24 h-1 appearance-none bg-gray-600 rounded-full outline-none"
            style={{
              WebkitAppearance: 'none',
              transform: 'rotate(-90deg)',
            }}
          />
        </div>
      )}
    </div>
  )
}

