import { Audio } from '../types/audio'
import { PlayCircle, Pause, Heart, FileText } from 'lucide-react'

const formatTime = (duration: number) => {
  const minutes = Math.floor(duration / 60);
  const seconds = Math.floor(duration % 60);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
};

const styles = {
  marquee: `
    @keyframes marquee {
      0% { transform: translateX(100%); }
      100% { transform: translateX(-100%); }
    }
    .animate-marquee {
      display: inline-block;
      white-space: nowrap;
      animation: marquee 10s linear infinite;
    }
  `,
};

interface AudioListProps {
  audioFiles: Audio[]
  onPlay: (audio: Audio) => void
  onToggleFavorite: (id: string) => void
  currentAudio: Audio | null
}

export default function AudioList({ audioFiles, onPlay, onToggleFavorite, currentAudio }: AudioListProps) {
  return (
    <div className="mt-4 sm:mt-6">
      <h2 className="text-xl sm:text-2xl font-semibold mb-2 sm:mb-4">Sua Biblioteca</h2>
      <ul className="grid grid-cols-4 gap-2">
        {audioFiles.map((audio) => (
          <li key={audio.id}>
            <div 
              className={`relative overflow-hidden rounded-lg ${
                currentAudio?.id === audio.id ? 'bg-blue-600' : 'bg-gray-700'
              } p-2 aspect-square flex flex-col justify-between`}
            >
              <div 
                onClick={() => onPlay(audio)} 
                className="absolute inset-0 w-full h-full z-10 cursor-pointer"
                role="button"
                tabIndex={0}
                onKeyPress={(e) => e.key === 'Enter' && onPlay(audio)}
                aria-label={currentAudio?.id === audio.id ? "Pausar" : "Reproduzir"}
              >
                <span className="absolute bottom-2 left-2 text-xs text-gray-300 bg-black bg-opacity-50 px-1 py-0.5 rounded">
                  {audio.duration ? formatTime(audio.duration) : '--:--'}
                </span>
              </div>
              <div className="absolute top-2 right-2 z-20 flex flex-col space-y-2">
                <div 
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    // TODO: Implement lyrics fetching and display
                    console.log('Fetch lyrics for:', audio.name);
                  }} 
                  className="bg-gray-800 bg-opacity-50 rounded-full p-1 cursor-pointer"
                  role="button"
                  tabIndex={0}
                  onKeyPress={(e) => e.key === 'Enter' && console.log('Fetch lyrics for:', audio.name)}
                  aria-label="Ver letra da música"
                >
                  <FileText className="w-4 h-4 text-white" />
                </div>
                <div 
                  onClick={(e) => { e.stopPropagation(); onToggleFavorite(audio.id); }} 
                  className="bg-gray-800 bg-opacity-50 rounded-full p-1 cursor-pointer"
                  role="button"
                  tabIndex={0}
                  onKeyPress={(e) => e.key === 'Enter' && onToggleFavorite(audio.id)}
                  aria-label={audio.isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
                >
                  <Heart
                    className={`w-4 h-4 ${
                      audio.isFavorite ? 'text-red-500 fill-current' : 'text-gray-400'
                    }`}
                  />
                </div>
              </div>
              <div className="flex justify-between items-start">
                <div className="w-8 h-8 flex items-center justify-center">
                  {currentAudio?.id === audio.id ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <PlayCircle className="w-6 h-6" />
                  )}
                </div>
              </div>
              <div className="overflow-hidden">
                <div className="animate-marquee whitespace-nowrap">
                  <span className="text-sm">{audio.name}</span>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

