import { Upload } from 'lucide-react'

interface UploadButtonProps {
  onUpload: (files: FileList) => void
}

export default function UploadButton({ onUpload }: UploadButtonProps) {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (files && files.length > 0) {
      onUpload(files)
    }
  }

  return (
    <div>
      <label
        htmlFor="audio-upload"
        className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700 transition duration-300 cursor-pointer"
      >
        <Upload className="w-6 h-6 text-white" />
      </label>
      <input
        id="audio-upload"
        type="file"
        accept="audio/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />
    </div>
  )
}

