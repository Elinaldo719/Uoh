import { Play, Pause, SkipBack, SkipForward, Shuffle } from 'lucide-react'
import VolumeControl from './VolumeControl'

interface ControlsProps {
  isPlaying: boolean
  onTogglePlay: () => void
  onNext: () => void
  onPrevious: () => void
  isRandom: boolean
  onToggleRandom: () => void
  volume: number
  onVolumeChange: (value: number) => void
}

export default function Controls({
  isPlaying,
  onTogglePlay,
  onNext,
  onPrevious,
  isRandom,
  onToggleRandom,
  volume,
  onVolumeChange,
}: ControlsProps) {
  return (
    <div className="flex justify-between items-center mb-4 sm:mb-6">
      <div className="w-20"> {/* Espaço vazio à esquerda para equilibrar o layout */}
      </div>
      <div className="flex items-center space-x-4">
        <button onClick={onPrevious} className="p-2 rounded-full hover:bg-gray-700">
          <SkipBack className="w-6 h-6" />
        </button>
        <button onClick={onTogglePlay} className="p-3 bg-blue-600 rounded-full hover:bg-blue-700">
          {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
        </button>
        <button onClick={onNext} className="p-2 rounded-full hover:bg-gray-700">
          <SkipForward className="w-6 h-6" />
        </button>
      </div>
      <div className="flex items-center space-x-4">
        <button
          onClick={onToggleRandom}
          className={`p-2 rounded-full ${isRandom ? 'bg-blue-600' : 'hover:bg-gray-700'}`}
        >
          <Shuffle className="w-6 h-6" />
        </button>
        <VolumeControl volume={volume} onVolumeChange={onVolumeChange} />
      </div>
    </div>
  )
}

