import Link from 'next/link'
import { List } from 'lucide-react'

export default function PlaylistIcon() {
  return (
    <Link href="/playlists" className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-600 hover:bg-green-700 transition duration-300">
      <List className="w-6 h-6 text-white" />
    </Link>
  )
}

