export interface Audio {
  id: string;
  name: string;
  url: string;
  isFavorite: boolean;
  lastPlayed?: Date;
}

